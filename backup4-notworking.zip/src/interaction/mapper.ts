import { MathUtils, Plane, Ray, Vector2, Vector3 } from 'three';
import type { Camera, Mesh } from 'three';
import type { HandData } from '../types';

const ndc = new Vector2();
const direction = new Vector3();
const origin = new Vector3();
const ray = new Ray();
const planeAnchor = new Vector3();

export interface DragContext {
  active: boolean;
  object: Mesh | null;
  plane: Plane;
  grabDepth: number;
  initialPinch: number;
  initialZ: number;
  grabOffset: Vector3;
  grabStartHand: Vector3;
  grabStartObject: Vector3;
  handWorld: Vector3;
  targetPoint: Vector3;
}

export const createDragContext = (): DragContext => ({
  active: false,
  object: null,
  plane: new Plane(),
  grabDepth: 0,
  initialPinch: 0,
  initialZ: 0,
  grabOffset: new Vector3(),
  grabStartHand: new Vector3(),
  grabStartObject: new Vector3(),
  handWorld: new Vector3(),
  targetPoint: new Vector3(),
});

const Z_SENSITIVITY = 5;
const MIN_Z = -10;
const MAX_Z = 10;

export const handToNdc = (hand: HandData, out = ndc): Vector2 => {
  const tip = hand.landmarks[8] ?? hand.centroid;
  out.set(-(tip.x * 2 - 1), -(tip.y * 2 - 1));
  return out;
};

export const rayFromHand = (camera: Camera, hand: HandData): Ray => {
  const coords = handToNdc(hand);
  origin.setFromMatrixPosition(camera.matrixWorld);
  direction.set(coords.x, coords.y, 0.5).unproject(camera).sub(origin).normalize();
  ray.set(origin, direction);
  return ray;
};

export const setDepthPlane = (camera: Camera, depth: number, outPlane: Plane): void => {
  camera.getWorldDirection(direction).normalize();
  origin.setFromMatrixPosition(camera.matrixWorld);
  planeAnchor.copy(origin).addScaledVector(direction, depth);
  outPlane.setFromNormalAndCoplanarPoint(direction, planeAnchor);
};

export const getHandWorldPosition = (
  camera: Camera,
  hand: HandData,
  plane: Plane,
  out: Vector3
): boolean => {
  const handRay = rayFromHand(camera, hand);
  return handRay.intersectPlane(plane, out) !== null;
};

export const beginGrab = (
  camera: Camera,
  hand: HandData,
  object: Mesh,
  drag: DragContext,
  outHand: Vector3
): void => {
  origin.setFromMatrixPosition(camera.matrixWorld);
  camera.getWorldDirection(direction).normalize();
  drag.grabDepth = planeAnchor.copy(object.position).sub(origin).dot(direction);
  setDepthPlane(camera, drag.grabDepth, drag.plane);

  if (!getHandWorldPosition(camera, hand, drag.plane, outHand)) {
    outHand.copy(object.position);
  }

  drag.active = true;
  drag.object = object;
  drag.grabStartHand.copy(outHand);
  drag.grabStartObject.copy(object.position);
  drag.grabOffset.copy(object.position).sub(outHand);
  drag.initialPinch = hand.pinchDistance;
  drag.initialZ = object.position.z;
  drag.targetPoint.copy(object.position);
};

export const computeDragTarget = (
  camera: Camera,
  hand: HandData,
  drag: DragContext,
  outTarget: Vector3
): boolean => {
  setDepthPlane(camera, drag.grabDepth, drag.plane);
  if (!getHandWorldPosition(camera, hand, drag.plane, drag.handWorld)) {
    return false;
  }

  const pinchDelta = hand.pinchDistance - drag.initialPinch;
  const targetZ = MathUtils.clamp(drag.initialZ + pinchDelta * Z_SENSITIVITY, MIN_Z, MAX_Z);

  outTarget.set(
    drag.handWorld.x + drag.grabOffset.x,
    drag.handWorld.y + drag.grabOffset.y,
    targetZ
  );

  drag.targetPoint.copy(outTarget);
  return true;
};

export const endGrab = (drag: DragContext): void => {
  drag.active = false;
  drag.object = null;
};

export const resetDragTarget = (drag: DragContext): void => {
  if (drag.object) {
    drag.targetPoint.copy(drag.object.position);
  }
};

export const applySmoothedDrag = (
  object: Mesh,
  target: Vector3,
  delta: Vector3,
  deadZone: number,
  maxExtremeJump: number,
  baseLerp: number
): void => {
  delta.copy(target).sub(object.position);
  const distance = delta.length();
  if (distance < deadZone) {
    return;
  }

  // Clamp only extreme jumps to keep interaction responsive but stable.
  if (distance > maxExtremeJump) {
    delta.multiplyScalar(maxExtremeJump / distance);
  }

  const dynamicLerp = MathUtils.clamp(0.2 + distance * 2.0, 0.2, 0.6);
  const lerpAlpha = Math.max(baseLerp, dynamicLerp);
  object.position.add(delta.multiplyScalar(lerpAlpha));
};

export const getRayDebugPoint = (distance = 5, out = planeAnchor): Vector3 => {
  out.copy(ray.origin).addScaledVector(ray.direction, distance);
  return out;
};
