import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Grid, OrbitControls } from '@react-three/drei';
import { useMemo, useRef } from 'react';
import { Intersection, Mesh, Object3D, Raycaster, Vector3 } from 'three';
import { useInteractionStore, type InteractionStateLabel } from '../stores/interactionStore';
import { trackingRuntime } from '../tracking/runtime';
import { InteractiveObject } from './InteractiveObject';
import {
  applySmoothedDrag,
  beginGrab,
  computeDragTarget,
  createDragContext,
  endGrab,
  getRayDebugPoint,
  rayFromHand,
} from '../interaction/mapper';

const raycaster = new Raycaster();
const smoothTarget = new Vector3();
const rayDirectionPoint = new Vector3();
const frameDelta = new Vector3();
const grabStartHandWorld = new Vector3();

const POSITION_LERP_ALPHA = 0.35;
const POSITION_DEADZONE = 0.002;
const MAX_EXTREME_JUMP = 1.2;

type StageOneState = 'IDLE' | 'HOVER' | 'SELECT' | 'DRAG' | 'RELEASE';

const SceneController = () => {
  const selectedObjectId = useInteractionStore((s) => s.selectedObjectId);
  const setSelectedObjectId = useInteractionStore((s) => s.setSelectedObjectId);
  const setInteractionMode = useInteractionStore((s) => s.setInteractionMode);
  const setInteractionState = useInteractionStore((s) => s.setInteractionState);

  const { camera, scene } = useThree();
  const objectRefs = useRef<Record<string, Mesh>>({});
  const rayHitDebugRef = useRef<Mesh>(null);
  const dragRef = useRef(createDragContext());
  const stageStateRef = useRef<StageOneState>('IDLE');
  const hoverFramesRef = useRef(0);
  const prevPinchRef = useRef(false);
  const prevGrabRef = useRef(false);
  const lastUiStateRef = useRef<InteractionStateLabel>('IDLE');
  const lastModeRef = useRef<'OBJECT_MODE' | 'CAMERA_MODE'>('CAMERA_MODE');
  const lastDebugKeyRef = useRef('');

  const registerObject = (id: string, mesh: Mesh) => {
    objectRefs.current[id] = mesh;
  };

  const updateUiMode = (nextMode: 'OBJECT_MODE' | 'CAMERA_MODE') => {
    if (lastModeRef.current !== nextMode) {
      lastModeRef.current = nextMode;
      setInteractionMode(nextMode);
    }
  };

  const updateUiState = (next: StageOneState) => {
    if (lastUiStateRef.current !== next) {
      lastUiStateRef.current = next;
      setInteractionState(next);
    }
  };

  const setRayDebugPoint = (point: Vector3 | null) => {
    const debugMesh = rayHitDebugRef.current;
    if (!debugMesh) {
      return;
    }

    if (!point) {
      debugMesh.visible = false;
      return;
    }

    debugMesh.visible = true;
    debugMesh.position.copy(point);
  };

  const isSelectableHit = (object: Object3D): boolean => {
    let current: Object3D | null = object;
    while (current) {
      if (current.userData?.selectable) {
        return true;
      }
      current = current.parent;
    }
    return false;
  };

  const findSelectableIntersection = (hits: Intersection<Object3D>[]): Intersection<Object3D> | null => {
    for (let i = 0; i < hits.length; i += 1) {
      if (isSelectableHit(hits[i].object)) {
        return hits[i];
      }
    }
    return null;
  };

  const resolveTrackedObjectId = (object: Object3D): string | null => {
    let current: Object3D | null = object;
    while (current) {
      const found = Object.entries(objectRefs.current).find((entry) => entry[1] === current);
      if (found) {
        return found[0];
      }
      current = current.parent;
    }
    return null;
  };

  const raycastObjectFromHand = (rightHand: NonNullable<typeof trackingRuntime.hands.right>) => {
    const handRay = rayFromHand(camera, rightHand);
    raycaster.ray.copy(handRay);

    rayDirectionPoint.copy(getRayDebugPoint(5, rayDirectionPoint));
    setRayDebugPoint(rayDirectionPoint);

    const hits = raycaster.intersectObjects(scene.children, true);
    const selectableHit = findSelectableIntersection(hits);

    const indexTip = rightHand.landmarks[8] ?? rightHand.centroid;
    const ndcX = -(indexTip.x * 2 - 1);
    const ndcY = -(indexTip.y * 2 - 1);

    console.log({
      ndcX,
      ndcY,
      intersects: hits.length,
    });

    if (!selectableHit) {
      return { id: null as string | null, mesh: null as Mesh | null, hitCount: 0 };
    }

    const id = resolveTrackedObjectId(selectableHit.object);
    if (id) {
      return { id, mesh: objectRefs.current[id], hitCount: hits.length };
    }

    return { id: null as string | null, mesh: null as Mesh | null, hitCount: hits.length };
  };

  useFrame(() => {
    const right = trackingRuntime.hands.right;
    const leftState = trackingRuntime.gestures.left;
    const rightState = trackingRuntime.gestures.right;
    const pinchActive = rightState === 'PINCH';
    const grabActive = rightState === 'GRAB';
    const leftActive = leftState === 'PINCH' || leftState === 'GRAB' || leftState === 'TRANSFORM';
    const noHandsActive = !pinchActive && !grabActive && !leftActive;

    let activeSelectedId = selectedObjectId;
    let activeSelected = activeSelectedId ? objectRefs.current[activeSelectedId] : null;

    if (!activeSelected && noHandsActive) {
      updateUiMode('CAMERA_MODE');
    } else {
      updateUiMode('OBJECT_MODE');
    }

    const hoverHit = right ? raycastObjectFromHand(right) : { id: null, mesh: null, hitCount: 0 };
    if (hoverHit.id) {
      hoverFramesRef.current += 1;
    } else {
      hoverFramesRef.current = 0;
    }

    if (!right && stageStateRef.current !== 'RELEASE') {
      if (prevPinchRef.current) {
        stageStateRef.current = 'RELEASE';
      } else {
        stageStateRef.current = 'IDLE';
      }
      endGrab(dragRef.current);
      updateUiState(stageStateRef.current);
      const debugKey = `${pinchActive}|${grabActive}|${activeSelectedId ?? 'None'}|${stageStateRef.current}|${lastModeRef.current}`;
      if (debugKey !== lastDebugKeyRef.current) {
        lastDebugKeyRef.current = debugKey;
        console.log({
          pinch: pinchActive,
          grab: grabActive,
          selected: activeSelectedId,
          state: stageStateRef.current,
          mode: lastModeRef.current,
        });
      }
      prevPinchRef.current = pinchActive;
      prevGrabRef.current = grabActive;
      return;
    }

    if (stageStateRef.current === 'IDLE' && hoverFramesRef.current >= 2) {
      stageStateRef.current = 'HOVER';
    }

    if (pinchActive && right) {
      const selectedHit = hoverHit.id ? hoverHit : raycastObjectFromHand(right);
      console.log({
        pinch: pinchActive,
        rayHits: selectedHit.hitCount,
      });
      if (selectedHit.id) {
        if (activeSelectedId !== selectedHit.id) {
          setSelectedObjectId(selectedHit.id);
          activeSelectedId = selectedHit.id;
          activeSelected = objectRefs.current[selectedHit.id];
        }
        stageStateRef.current = 'SELECT';
        updateUiMode('OBJECT_MODE');
      } else {
        if (activeSelectedId) {
          setSelectedObjectId(null);
          activeSelectedId = null;
          activeSelected = null;
        }
        if (stageStateRef.current !== 'DRAG') {
          stageStateRef.current = 'HOVER';
        }
      }
    }

    if (!pinchActive && prevPinchRef.current && stageStateRef.current !== 'DRAG') {
      stageStateRef.current = 'RELEASE';
    }

    const grabStart = grabActive && !prevGrabRef.current;
    if (grabStart && activeSelected && right) {
      beginGrab(camera, right, activeSelected, dragRef.current, grabStartHandWorld);
      stageStateRef.current = 'DRAG';
      updateUiMode('OBJECT_MODE');
    }

    if (grabActive && activeSelected && right) {
      if (!dragRef.current.active || dragRef.current.object !== activeSelected) {
        beginGrab(camera, right, activeSelected, dragRef.current, grabStartHandWorld);
      }
      stageStateRef.current = 'DRAG';
    }

    if (stageStateRef.current === 'DRAG' && right && grabActive && dragRef.current.active && dragRef.current.object) {
      if (computeDragTarget(camera, right, dragRef.current, smoothTarget)) {
        applySmoothedDrag(
          dragRef.current.object,
          smoothTarget,
          frameDelta,
          POSITION_DEADZONE,
          MAX_EXTREME_JUMP,
          POSITION_LERP_ALPHA
        );
      }
    }

    const grabRelease = !grabActive && prevGrabRef.current;
    if (grabRelease) {
      stageStateRef.current = 'RELEASE';
      endGrab(dragRef.current);
    }

    if (stageStateRef.current === 'DRAG' && (!right || rightState === 'RELEASE' || rightState === 'IDLE')) {
      stageStateRef.current = 'RELEASE';
      endGrab(dragRef.current);
    }

    if (stageStateRef.current === 'RELEASE') {
      stageStateRef.current = right ? 'HOVER' : 'IDLE';
      endGrab(dragRef.current);
    }

    if (!pinchActive) {
      setRayDebugPoint(null);
    }

    updateUiState(stageStateRef.current);

    const debugKey = `${pinchActive}|${grabActive}|${activeSelectedId ?? 'None'}|${stageStateRef.current}|${lastModeRef.current}`;
    if (debugKey !== lastDebugKeyRef.current) {
      lastDebugKeyRef.current = debugKey;
      console.log({
        pinch: pinchActive,
        grab: grabActive,
        selected: activeSelectedId,
        state: stageStateRef.current,
        mode: lastModeRef.current,
      });
    }

    prevPinchRef.current = pinchActive;
    prevGrabRef.current = grabActive;
  });

  return (
    <>
      <ambientLight intensity={0.45} />
      <directionalLight position={[6, 9, 5]} intensity={1.4} castShadow />
      <Grid
        args={[60, 60]}
        cellColor="#2f3b4e"
        sectionColor="#5b6d8e"
        fadeDistance={110}
        fadeStrength={1}
        infiniteGrid
      />
      <InteractiveObject
        id="cube"
        kind="cube"
        position={[-1.8, 1, 0]}
        selected={selectedObjectId === 'cube'}
        onReady={registerObject}
      />
      <InteractiveObject
        id="sphere"
        kind="sphere"
        position={[1.8, 1, 0]}
        selected={selectedObjectId === 'sphere'}
        onReady={registerObject}
      />
      <mesh ref={rayHitDebugRef} visible={false}>
        <sphereGeometry args={[0.06]} />
        <meshBasicMaterial color="#ff2d55" />
      </mesh>
      <OrbitControls makeDefault enablePan={false} maxPolarAngle={Math.PI * 0.48} minDistance={6} maxDistance={22} />
    </>
  );
};

export const SceneRoot = () => {
  const cameraPosition = useMemo<[number, number, number]>(() => [0, 5.4, 11], []);

  return (
    <Canvas camera={{ position: cameraPosition, fov: 48 }} shadows gl={{ antialias: true }}>
      <color attach="background" args={['#0b1018']} />
      <fog attach="fog" args={['#0b1018', 12, 36]} />
      <SceneController />
    </Canvas>
  );
};
