import { useOverlayState } from '../stores/interactionStore';

export const Overlay = () => {
  const {
    fps,
    currentGesture,
    selectedObjectId,
    trackerStatus,
    showLandmarkOverlay,
    moveMode,
    interactionMode,
    interactionState,
    toggleLandmarkOverlay,
    setMoveMode,
  } = useOverlayState();

  return (
    <div className="hud">
      <div className="hud__card">
        <h1>Two-Hand Interaction</h1>
        <p>FPS: {fps.toFixed(1)}</p>
        <p>Gesture: {currentGesture}</p>
        <p>Selected: {selectedObjectId ?? 'None'}</p>
        <p>Mode: {interactionMode}</p>
        <p>State: {interactionState}</p>
        <p>Status: {trackerStatus}</p>
        <div className="hud__controls">
          <button onClick={toggleLandmarkOverlay} type="button">
            Overlay: {showLandmarkOverlay ? 'On' : 'Off'}
          </button>
          <button
            onClick={() => setMoveMode(moveMode === 'relative' ? 'absolute' : 'relative')}
            type="button"
          >
            Move: {moveMode}
          </button>
        </div>
      </div>
      <p className="hud__tip">
        Stage 1 active: right hand pinch selects, right hand grab performs smoothed X/Y/Z object drag.
      </p>
    </div>
  );
};
