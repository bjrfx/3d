import { Plane, Ray, Vector2, Vector3 } from 'three';
import type { Camera } from 'three';
import type { HandData } from '../types';

const ndc = new Vector2();
const direction = new Vector3();
const origin = new Vector3();
const ray = new Ray();
const cameraForward = new Vector3();

const Z_FROM_HAND_SCALE = 9.5;
const Z_FROM_PINCH_SCALE = 4.2;

export interface DragContext {
  active: boolean;
  plane: Plane;
  grabDepth: number;
  initialHandZ: number;
  initialPinchDistance: number;
  grabOffset: Vector3;
  previousPoint: Vector3 | null;
  targetPoint: Vector3;
}

export const createDragContext = (): DragContext => ({
  active: false,
  plane: new Plane(),
  grabDepth: 0,
  initialHandZ: 0,
  initialPinchDistance: 0,
  grabOffset: new Vector3(),
  previousPoint: null,
  targetPoint: new Vector3(),
});

export const handToNdc = (hand: HandData): Vector2 => {
  ndc.set(hand.centroid.x * 2 - 1, -(hand.centroid.y * 2 - 1));
  return ndc;
};

export const intersectHandWithPlane = (
  camera: Camera,
  hand: HandData,
  plane: Plane,
  target: Vector3
): boolean => {
  const coords = handToNdc(hand);
  origin.setFromMatrixPosition(camera.matrixWorld);
  direction.set(coords.x, coords.y, 0.5).unproject(camera).sub(origin).normalize();
  ray.set(origin, direction);
  return ray.intersectPlane(plane, target) !== null;
};

export const beginDragPlane = (
  camera: Camera,
  pointOnObject: Vector3,
  hand: HandData,
  hitPoint: Vector3,
  drag: DragContext
): void => {
  camera.getWorldDirection(direction).normalize();
  drag.plane.setFromNormalAndCoplanarPoint(direction, pointOnObject);
  origin.setFromMatrixPosition(camera.matrixWorld);
  drag.grabDepth = origin.distanceTo(hitPoint);
  drag.initialHandZ = hand.centroid.z;
  drag.initialPinchDistance = hand.pinchDistance;
  drag.grabOffset.copy(pointOnObject).sub(hitPoint);
  drag.previousPoint = null;
  drag.targetPoint.copy(pointOnObject);
  drag.active = true;
};

export const updateDragPlaneDepth = (camera: Camera, drag: DragContext): void => {
  camera.getWorldDirection(direction).normalize();
  origin.setFromMatrixPosition(camera.matrixWorld);
  drag.plane.setFromNormalAndCoplanarPoint(direction, origin.addScaledVector(direction, drag.grabDepth));
};

export const computeDepthDelta = (hand: HandData, drag: DragContext): number => {
  const handDepthDelta = (hand.centroid.z - drag.initialHandZ) * Z_FROM_HAND_SCALE;
  const pinchDepthProxy = (drag.initialPinchDistance - hand.pinchDistance) * Z_FROM_PINCH_SCALE;
  return handDepthDelta + pinchDepthProxy;
};

export const computeDragTarget = (
  camera: Camera,
  hand: HandData,
  drag: DragContext,
  outTarget: Vector3,
  planeHitPoint: Vector3
): boolean => {
  updateDragPlaneDepth(camera, drag);
  if (!intersectHandWithPlane(camera, hand, drag.plane, planeHitPoint)) {
    return false;
  }

  camera.getWorldDirection(cameraForward).normalize();
  const zDelta = computeDepthDelta(hand, drag);
  outTarget.copy(planeHitPoint).add(drag.grabOffset).addScaledVector(cameraForward, zDelta);
  drag.targetPoint.copy(outTarget);
  return true;
};

export const applyRelativeMove = (
  objectPosition: Vector3,
  nextPoint: Vector3,
  drag: DragContext
): void => {
  if (!drag.previousPoint) {
    drag.previousPoint = nextPoint.clone();
    return;
  }

  objectPosition.add(drag.targetPoint.copy(nextPoint).sub(drag.previousPoint));
  drag.previousPoint.copy(nextPoint);
};

export const applyAbsoluteMove = (
  objectPosition: Vector3,
  nextPoint: Vector3,
  offset: Vector3
): void => {
  objectPosition.copy(nextPoint).add(offset);
};
