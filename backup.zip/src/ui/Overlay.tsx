import { useOverlayState } from '../stores/interactionStore';

export const Overlay = () => {
  const {
    fps,
    currentGesture,
    selectedObjectId,
    trackerStatus,
    showLandmarkOverlay,
    moveMode,
    toggleLandmarkOverlay,
    setMoveMode,
  } = useOverlayState();

  return (
    <div className="hud">
      <div className="hud__card">
        <h1>Two-Hand Interaction</h1>
        <p>FPS: {fps.toFixed(1)}</p>
        <p>Gesture: {currentGesture}</p>
        <p>Selected: {selectedObjectId ?? 'None'}</p>
        <p>Status: {trackerStatus}</p>
        <div className="hud__controls">
          <button onClick={toggleLandmarkOverlay} type="button">
            Overlay: {showLandmarkOverlay ? 'On' : 'Off'}
          </button>
          <button
            onClick={() => setMoveMode(moveMode === 'relative' ? 'absolute' : 'relative')}
            type="button"
          >
            Move: {moveMode}
          </button>
        </div>
      </div>
      <p className="hud__tip">
        Right hand pinch selects and moves. Two hands in TRANSFORM state scale and rotate the selected object.
      </p>
    </div>
  );
};
