import { create } from 'zustand';
import type { GestureState } from '../types';

export type MoveMode = 'relative' | 'absolute';

interface InteractionState {
  fps: number;
  currentGesture: string;
  selectedObjectId: string | null;
  trackerStatus: 'loading' | 'ready' | 'error';
  showLandmarkOverlay: boolean;
  moveMode: MoveMode;
  setFps: (fps: number) => void;
  setCurrentGesture: (gesture: string) => void;
  setSelectedObjectId: (id: string | null) => void;
  setTrackerStatus: (status: InteractionState['trackerStatus']) => void;
  toggleLandmarkOverlay: () => void;
  setMoveMode: (mode: MoveMode) => void;
}

export const useInteractionStore = create<InteractionState>((set) => ({
  fps: 0,
  currentGesture: 'IDLE',
  selectedObjectId: null,
  trackerStatus: 'loading',
  showLandmarkOverlay: true,
  moveMode: 'relative',
  setFps: (fps) => set({ fps }),
  setCurrentGesture: (gesture) => set({ currentGesture: gesture }),
  setSelectedObjectId: (selectedObjectId) => set({ selectedObjectId }),
  setTrackerStatus: (trackerStatus) => set({ trackerStatus }),
  toggleLandmarkOverlay: () => set((state) => ({ showLandmarkOverlay: !state.showLandmarkOverlay })),
  setMoveMode: (moveMode) => set({ moveMode }),
}));

export const useOverlayState = () => {
  const fps = useInteractionStore((s) => s.fps);
  const currentGesture = useInteractionStore((s) => s.currentGesture);
  const selectedObjectId = useInteractionStore((s) => s.selectedObjectId);
  const trackerStatus = useInteractionStore((s) => s.trackerStatus);
  const showLandmarkOverlay = useInteractionStore((s) => s.showLandmarkOverlay);
  const moveMode = useInteractionStore((s) => s.moveMode);
  const toggleLandmarkOverlay = useInteractionStore((s) => s.toggleLandmarkOverlay);
  const setMoveMode = useInteractionStore((s) => s.setMoveMode);

  return {
    fps,
    currentGesture,
    selectedObjectId,
    trackerStatus,
    showLandmarkOverlay,
    moveMode,
    toggleLandmarkOverlay,
    setMoveMode,
  };
};

export const toGestureLabel = (left: GestureState, right: GestureState): string => {
  if (left === 'TRANSFORM' && right === 'TRANSFORM') {
    return 'TRANSFORM';
  }

  if (right !== 'IDLE') {
    return `RIGHT_${right}`;
  }

  if (left !== 'IDLE') {
    return `LEFT_${left}`;
  }

  return 'IDLE';
};
