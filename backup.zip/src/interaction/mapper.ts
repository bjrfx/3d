import { Plane, Ray, Vector2, Vector3 } from 'three';
import type { Camera } from 'three';
import type { HandData } from '../types';

const ndc = new Vector2();
const direction = new Vector3();
const origin = new Vector3();
const ray = new Ray();
const hit = new Vector3();

export interface DragContext {
  active: boolean;
  plane: Plane;
  previousPoint: Vector3 | null;
}

export const createDragContext = (): DragContext => ({
  active: false,
  plane: new Plane(),
  previousPoint: null,
});

export const handToNdc = (hand: HandData): Vector2 => {
  ndc.set((1 - hand.centroid.x) * 2 - 1, -(hand.centroid.y * 2 - 1));
  return ndc;
};

export const intersectHandWithPlane = (
  camera: Camera,
  hand: HandData,
  plane: Plane,
  target: Vector3
): boolean => {
  const coords = handToNdc(hand);
  origin.setFromMatrixPosition(camera.matrixWorld);
  direction.set(coords.x, coords.y, 0.5).unproject(camera).sub(origin).normalize();
  ray.set(origin, direction);
  return ray.intersectPlane(plane, target) !== null;
};

export const beginDragPlane = (
  camera: Camera,
  pointOnObject: Vector3,
  drag: DragContext
): void => {
  camera.getWorldDirection(direction).normalize();
  drag.plane.setFromNormalAndCoplanarPoint(direction, pointOnObject);
  drag.previousPoint = null;
  drag.active = true;
};

export const applyRelativeMove = (
  objectPosition: Vector3,
  nextPoint: Vector3,
  drag: DragContext
): void => {
  if (!drag.previousPoint) {
    drag.previousPoint = nextPoint.clone();
    return;
  }

  objectPosition.add(hit.copy(nextPoint).sub(drag.previousPoint));
  drag.previousPoint.copy(nextPoint);
};

export const applyAbsoluteMove = (
  objectPosition: Vector3,
  nextPoint: Vector3,
  offset: Vector3
): void => {
  objectPosition.copy(nextPoint).add(offset);
};
