import { isHandOpen } from '../math/handMath';
import type { GestureState, Landmark } from '../types';

interface InternalState {
  state: GestureState;
  pinchFrames: number;
  openFrames: number;
  holdFrames: number;
}

const MIN_PINCH_FRAMES = 2;
const MIN_OPEN_FRAMES = 2;
const HOLD_FRAMES_FOR_GRAB = 4;

export class GestureEngine {
  private left: InternalState = { state: 'IDLE', pinchFrames: 0, openFrames: 0, holdFrames: 0 };

  private right: InternalState = { state: 'IDLE', pinchFrames: 0, openFrames: 0, holdFrames: 0 };

  update(
    leftLandmarks: Landmark[] | null,
    rightLandmarks: Landmark[] | null,
    leftPinch: boolean,
    rightPinch: boolean,
    bothPresent: boolean
  ): { left: GestureState; right: GestureState } {
    this.left = this.advance(this.left, leftLandmarks, leftPinch, bothPresent);
    this.right = this.advance(this.right, rightLandmarks, rightPinch, bothPresent);

    if (bothPresent && this.isActive(this.left.state) && this.isActive(this.right.state)) {
      this.left.state = 'TRANSFORM';
      this.right.state = 'TRANSFORM';
    }

    return { left: this.left.state, right: this.right.state };
  }

  private isActive(state: GestureState): boolean {
    return state === 'PINCH_START' || state === 'GRAB' || state === 'TRANSFORM';
  }

  private advance(
    current: InternalState,
    landmarks: Landmark[] | null,
    isPinching: boolean,
    bothPresent: boolean
  ): InternalState {
    if (!landmarks) {
      return { state: 'IDLE', pinchFrames: 0, openFrames: 0, holdFrames: 0 };
    }

    const next: InternalState = { ...current };
    const open = isHandOpen(landmarks);

    if (isPinching) {
      next.pinchFrames += 1;
      next.openFrames = 0;
      next.holdFrames += 1;
    } else {
      next.pinchFrames = 0;
      next.holdFrames = 0;
      next.openFrames = open ? next.openFrames + 1 : 0;
    }

    switch (next.state) {
      case 'IDLE':
        if (next.pinchFrames >= MIN_PINCH_FRAMES) {
          next.state = 'PINCH_START';
        }
        break;
      case 'PINCH_START':
        if (!isPinching) {
          next.state = 'RELEASE';
          break;
        }
        if (next.holdFrames >= HOLD_FRAMES_FOR_GRAB) {
          next.state = bothPresent ? 'TRANSFORM' : 'GRAB';
        }
        break;
      case 'GRAB':
        if (!isPinching && next.openFrames >= MIN_OPEN_FRAMES) {
          next.state = 'RELEASE';
        }
        if (bothPresent && isPinching) {
          next.state = 'TRANSFORM';
        }
        break;
      case 'TRANSFORM':
        if (!isPinching && next.openFrames >= MIN_OPEN_FRAMES) {
          next.state = 'RELEASE';
        }
        if (!bothPresent && isPinching) {
          next.state = 'GRAB';
        }
        break;
      case 'RELEASE':
        next.state = isPinching ? 'PINCH_START' : 'IDLE';
        next.pinchFrames = isPinching ? 1 : 0;
        next.openFrames = 0;
        next.holdFrames = isPinching ? 1 : 0;
        break;
      default:
        next.state = 'IDLE';
    }

    return next;
  }
}
