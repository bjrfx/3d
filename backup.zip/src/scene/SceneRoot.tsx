import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Grid, OrbitControls } from '@react-three/drei';
import { useMemo, useRef } from 'react';
import { Mesh, Raycaster, Vector2, Vector3 } from 'three';
import { useInteractionStore } from '../stores/interactionStore';
import { trackingRuntime } from '../tracking/runtime';
import { InteractiveObject } from './InteractiveObject';
import {
  applyAbsoluteMove,
  applyRelativeMove,
  beginDragPlane,
  createDragContext,
  handToNdc,
  intersectHandWithPlane,
} from '../interaction/mapper';

const raycaster = new Raycaster();
const tmpNdc = new Vector2();
const tmpPoint = new Vector3();
const tmpOffset = new Vector3();
const SceneController = () => {
  const selectedObjectId = useInteractionStore((s) => s.selectedObjectId);
  const setSelectedObjectId = useInteractionStore((s) => s.setSelectedObjectId);
  const moveMode = useInteractionStore((s) => s.moveMode);

  const { camera } = useThree();
  const objectRefs = useRef<Record<string, Mesh>>({});
  const drag = useRef(createDragContext());
  const transformState = useRef({
    active: false,
    baseDistance: 0,
    baseAngle: 0,
    baseScale: new Vector3(1, 1, 1),
    baseRotationZ: 0,
  });

  const registerObject = (id: string, mesh: Mesh) => {
    objectRefs.current[id] = mesh;
  };

  const selectByRightHand = () => {
    const right = trackingRuntime.hands.right;
    if (!right) {
      return;
    }

    tmpNdc.copy(handToNdc(right));
    raycaster.setFromCamera(tmpNdc, camera);
    const targets = Object.values(objectRefs.current);
    const hits = raycaster.intersectObjects(targets, false);
    if (hits.length > 0) {
      const picked = hits[0].object as Mesh;
      const id = Object.entries(objectRefs.current).find((entry) => entry[1] === picked)?.[0] ?? null;
      setSelectedObjectId(id);
    }
  };

  useFrame(() => {
    const right = trackingRuntime.hands.right;
    const left = trackingRuntime.hands.left;
    const rightState = trackingRuntime.gestures.right;
    const leftState = trackingRuntime.gestures.left;

    const selected = selectedObjectId ? objectRefs.current[selectedObjectId] : null;

    if (rightState === 'PINCH_START') {
      selectByRightHand();
    }

    if (!selected) {
      drag.current.active = false;
      transformState.current.active = false;
      return;
    }

    if (right && (rightState === 'GRAB' || rightState === 'TRANSFORM')) {
      if (!drag.current.active) {
        beginDragPlane(camera, selected.position.clone(), drag.current);

        if (moveMode === 'absolute' && intersectHandWithPlane(camera, right, drag.current.plane, tmpPoint)) {
          tmpOffset.copy(selected.position).sub(tmpPoint);
        }
      }

      if (intersectHandWithPlane(camera, right, drag.current.plane, tmpPoint)) {
        if (moveMode === 'relative') {
          applyRelativeMove(selected.position, tmpPoint, drag.current);
        } else {
          applyAbsoluteMove(selected.position, tmpPoint, tmpOffset);
        }
      }
    } else {
      drag.current.active = false;
    }

    if (left && right && leftState === 'TRANSFORM' && rightState === 'TRANSFORM') {
      const lc = left.centroid;
      const rc = right.centroid;
      const dx = rc.x - lc.x;
      const dy = rc.y - lc.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const angle = Math.atan2(dy, dx);

      if (!transformState.current.active) {
        transformState.current.active = true;
        transformState.current.baseDistance = Math.max(dist, 0.02);
        transformState.current.baseAngle = angle;
        transformState.current.baseScale.copy(selected.scale);
        transformState.current.baseRotationZ = selected.rotation.z;
      }

      const ratio = Math.min(3, Math.max(0.3, dist / transformState.current.baseDistance));
      selected.scale.copy(transformState.current.baseScale).multiplyScalar(ratio);
      selected.rotation.z = transformState.current.baseRotationZ + (angle - transformState.current.baseAngle);
    } else {
      transformState.current.active = false;
    }
  });

  return (
    <>
      <ambientLight intensity={0.45} />
      <directionalLight position={[6, 9, 5]} intensity={1.4} castShadow />
      <Grid
        args={[60, 60]}
        cellColor="#2f3b4e"
        sectionColor="#5b6d8e"
        fadeDistance={110}
        fadeStrength={1}
        infiniteGrid
      />
      <InteractiveObject
        id="cube"
        kind="cube"
        position={[-1.8, 1, 0]}
        selected={selectedObjectId === 'cube'}
        onReady={registerObject}
      />
      <InteractiveObject
        id="sphere"
        kind="sphere"
        position={[1.8, 1, 0]}
        selected={selectedObjectId === 'sphere'}
        onReady={registerObject}
      />
      <OrbitControls makeDefault enablePan={false} maxPolarAngle={Math.PI * 0.48} minDistance={6} maxDistance={22} />
    </>
  );
};

export const SceneRoot = () => {
  const cameraPosition = useMemo<[number, number, number]>(() => [0, 5.4, 11], []);

  return (
    <Canvas camera={{ position: cameraPosition, fov: 48 }} shadows gl={{ antialias: true }}>
      <color attach="background" args={['#0b1018']} />
      <fog attach="fog" args={['#0b1018', 12, 36]} />
      <SceneController />
    </Canvas>
  );
};
